package littleMaidMobX.ai;

import net.minecraft.entity.ai.EntityAIBase;

public class AITemptMove extends EntityAIBase {

	@Override
	public boolean shouldExecute() {
		// TODO Auto-generated method stub
		return false;
	}

}
