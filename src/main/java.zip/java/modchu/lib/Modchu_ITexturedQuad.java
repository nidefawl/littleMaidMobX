package modchu.lib;

public interface Modchu_ITexturedQuad {
	public void setInvertNormal(boolean b);
	public void flipFace();
	public void draw(Object worldRendererOrTessellator, float f);

}
