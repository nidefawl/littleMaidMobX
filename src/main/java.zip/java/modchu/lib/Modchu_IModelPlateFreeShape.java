package modchu.lib;

public interface Modchu_IModelPlateFreeShape {

	public void render(Object o, float f);

}
