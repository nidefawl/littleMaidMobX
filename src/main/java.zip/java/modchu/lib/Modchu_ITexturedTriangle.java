package modchu.lib;

public interface Modchu_ITexturedTriangle {

	public void flipFace();
	public void draw(Object var1, float var2);

}
