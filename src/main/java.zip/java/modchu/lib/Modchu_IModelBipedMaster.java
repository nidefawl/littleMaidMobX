package modchu.lib;

public interface Modchu_IModelBipedMaster extends Modchu_IModelBaseMaster {
	public void renderEars(float par1);
	public void renderCloak(float par1);

}
